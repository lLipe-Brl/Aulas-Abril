    # pip install selenium

# Módulo para controlar o navegador
from selenium import webdriver

# Localizador de elementos
from selenium.webdriver.common.by import By

# Serviço para configurar o caminho do executável Chrome Driver
from selenium.webdriver.chrome.service import Service

# Classe que permite executar ações avançadas (exemplo: mover do mouse, clique arrasta)
from selenium.webdriver.common.action_chains import ActionChains

# A Classe que espera de forma explícita até que uma condição seja satisfeita
from selenium.webdriver.support.ui import WebDriverWait

# Condições esperadas usadas com WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

# Trabalhar com dados em tabelas ou Dataframes
import pandas as pd

# Uso de funções relacionadas a tempo
import time

from selenium.common.exceptions import TimeoutException

# Definir o caminho do Chromedriver
chrome_driver_path =  "C:/Program Files/chromedriver-win64/chromedriver.exe"

# Configuração do Webdriver
service = Service(chrome_driver_path) # Navegador controlado pelo Selenium
options = webdriver.ChromeOptions() # Configurar as opções do Navegador
options.add_argument('--disable-gpu') # Evita possíveis erros gráficos
options.add_argument('--window-size=1920,1080') # Define uma resolução fixa


#Inicialização do Webdriver
driver = webdriver.Chrome(service=service, options=options)

# URL inicial
url_base = 'https://www.kabum.com.br/espaco-gamer/cadeiras-gamer'
driver.get(url_base)
time.sleep(5) # Aguarda 5 segundos até a página carregar

# Criar um dicionário para armazenar os nomes e preços das cadeiras
dic_produtos = {'marca': [], 'preco':[]}

# Vamos iniciar na página 1 e incrementamos a cada troca de página
pagina = 1

while True:
    print()
    print(f"Coletando dados da página {pagina}...")

    try:
        # Significa que ele vai criar uma espera de até 10 segundos
        # Untill faz com que o código espere até que a condição seja verdadeira 
        # presence_of_all_elements_located verificar se todos os elementos da classe productCard estão acessíveis
        # By.CLASS_NAME, "productCard" indica que a busca será feita por meio da classe
        WebDriverWait(driver, 10).until(
        # Essa é a condição, de encontrar o productCard
            ec.presence_of_all_elements_located((By.CLASS_NAME, "productCard"))
    )
        print("Elementos encontrados com sucesso.")
    except TimeoutException:
        print("Tempo de espera excedido")

    produtos = driver.find_elements(By.CLASS_NAME, "productCard")

    for produto in produtos:
        try:
            nome = produto.find_element(By.CLASS_NAME, "nameCard").text.strip()
            preco = produto.find_element(By.CLASS_NAME, "priceCard").text.strip()

            print (f"{nome} - {preco}")

            dic_produtos["marca"].append(nome)
            dic_produtos["preco"].append(preco)

        except Exception:
            print("Erro ao coletar dados:", Exception)

# Encontrar o acesso (botão) para a próxima página

    try:
        botao_proxima = WebDriverWait(driver, 5).until(
            ec.element_to_be_clickable((By.CLASS_NAME, 'nextLink'))
    )
    # Todo o trecho abaixo está fazendo ações com o mouse.
        if botao_proxima:
            driver.execute_script("arguments[0].scrollIntoView();", botao_proxima)
            time.sleep(1)
            driver.execute_script("arguments[0].click();", botao_proxima)
            print(f"Indo para a página {pagina}")
            pagina += 1

            time.sleep(5)

        else:
            print("Você chegou na última página!")
            break

    except Exception as e:
        print("Erro ao tentar avançar para a próxima página", e)
        break

# Fechando o navegador
driver.quit()

df = pd.DataFrame(dic_produtos)
df.to_excel("Cadeiras.xlsx", index=False)

print(f"Arquivo Cadeiras salvo com sucesso! ({len(df)}) produtos capturados")

