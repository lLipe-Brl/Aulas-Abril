from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
import pandas as pd
import time
import datetime


chrome_driver_path = "C:/Program Files/chromedriver-win64/chromedriver.exe"
service = Service(chrome_driver_path) 
opcoes = webdriver.ChromeOptions() 
opcoes.add_argument('--disable-gpu')
opcoes.add_argument('--window-size=1920,1080') 
opcoes.add_argument('')

driver = webdriver.Chrome(service=service, opcoes=opcoes)
url = 'https://www.kabum.com.br/hardware/placa-de-video-vga'
driver.get(url)
start_time = time.time()
time.sleep(5)

dicionario = {'nome': [], 'valor': []}
pagina = 1
total_produtos = 0

while True:
    print(f"\nColetando dados da página {pagina}...")

    try:
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.CLASS_NAME, "productCard"))
        )
        print("Elementos encontrados com sucesso.")
    except TimeoutException:
        print("Tempo de espera excedido. Nenhum elemento encontrado.")
        break

    placas = driver.find_elements(By.CLASS_NAME, "productCard")

    for placa in placas:
        try:
            nome = placa.find_element(By.CLASS_NAME, "nameCard").text.strip()
            valor = placa.find_element(By.CLASS_NAME, "priceCard").text.strip()
            print(f"{nome} - {valor}")

            dicionario["nome"].append(nome)
            dicionario["valor"].append(valor)
            total_produtos += 1

        except Exception as e:
            print("Erro ao coletar dados:", e)

    try:
        botao_proxima = WebDriverWait(driver, 5).until(
            ec.element_to_be_clickable((By.CLASS_NAME, 'nextLink'))
        )
        pagina_atual = driver.current_url
        driver.execute_script("arguments[0].scrollIntoView();", botao_proxima)
        time.sleep(1)
        driver.execute_script("arguments[0].click();", botao_proxima)
        time.sleep(5)
        if driver.current_url == pagina_atual:
            print("A URL não mudou. Provavelmente a última página.")
            break
        pagina += 1

    except Exception as excecao:
        print("Erro ao tentar avançar para a próxima página:", excecao)
        break

driver.quit()

df = pd.DataFrame(dicionario)
arquivo_nome = f"placas_de_video_kabum{datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S')}.csv"
df.to_csv(arquivo_nome, index=False, encoding='utf-8-sig')

tempo_total = time.time() - start_time
print(f"\nRaspagem finalizada! {total_produtos} produtos coletados.")
print(f"Arquivo salvo como: {arquivo_nome}")
print(f"Tempo total de execução: {tempo_total:.2f} segundos.")
