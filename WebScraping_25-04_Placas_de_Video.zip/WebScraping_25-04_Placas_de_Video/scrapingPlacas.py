from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException
import pandas as pd
import time

chrome_driver_path = "C:/Program Files/chromedriver-win64/chromedriver.exe"
service = Service(chrome_driver_path) 
options = webdriver.ChromeOptions() 
options.add_argument('--disable-gpu')
options.add_argument('--window-size=1920,1080') 


# Navegar pelo site
driver = webdriver.Chrome(service=service, options=options)
url = 'https://www.kabum.com.br/hardware/placa-de-video-vga'
driver.get(url)
driver.maximize_window()
start_time = time.time()
time.sleep(5)

# Criando um Dicionário, separando por nome e valor 
dicionario = {'nome': [], 'valor': []}
pagina = 1
total_produtos = 0

# Looping para acessar cada página até o final
while True:
    print(f"\nColetando dados da página {pagina}...")

    try:
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.CLASS_NAME, "productCard"))
        )
        print("Elementos encontrados com sucesso.")
    except TimeoutException:
        print("Tempo de espera excedido. Nenhum elemento encontrado.")
        break

    placas = driver.find_elements(By.CLASS_NAME, "productCard")

    for placa in placas:
        try:
            nome = placa.find_element(By.CLASS_NAME, "nameCard").text.strip()
            valor = placa.find_element(By.CLASS_NAME, "priceCard").text.strip()
            print(f"{nome} - {valor}")

            dicionario["nome"].append(nome)
            dicionario["valor"].append(valor)
            total_produtos += 1

        except Exception as e:
            print("Erro ao coletar dados:", e)

    try:
        botao_proxima = WebDriverWait(driver, 5).until(
            ec.element_to_be_clickable((By.CLASS_NAME, 'nextLink'))
        )
        pagina_atual = driver.current_url
        driver.execute_script("arguments[0].scrollIntoView();", botao_proxima)
        time.sleep(1)
        driver.execute_script("arguments[0].click();", botao_proxima)
        time.sleep(5)
        if driver.current_url == pagina_atual:
            print("A URL não mudou. Provavelmente a última página.")
            break
        pagina += 1

    except Exception as excecao:
        print("Erro ao tentar avançar para a próxima página:", excecao)
        break

# Saindo do programa
driver.quit()

# Salvando os dados num novo arquivo Excel (.xlsx)
df = pd.DataFrame(dicionario)
df.to_excel("placas_kabum.xlsx", index=False)

print(f"Arquivo Cadeiras salvo com sucesso! ({len(df)}) produtos capturados")
