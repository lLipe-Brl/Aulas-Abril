
# pip install selenium
# Módulo par controlar o navegador
from selenium import webdriver

# Localizador de elementos
from selenium.webdriver.common.by import By

# Serviço para configurar o caminho do executável chromedriver
from selenium.webdriver.chrome.service import Service 

# Classe que permite executar ações avançadas (o mover do mouse, clique/arrasta)
from selenium.webdriver.common.action_chains import ActionChains

# Classe que espera de forma explícita, até que uma contição seja satisfeita
# (ex: que um elemento apareça)
from selenium.webdriver.support.ui import WebDriverWait

# condições esperadas usadas com WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

# Trabalhar com dados em tabelas ou dataframes
import pandas as pd

# Funções relacionada a tempo
import time

#uso de tratamento de excessão
from selenium.common.exceptions import TimeoutException

# Definir o caminho do chromedriver
chrome_driver_path = "C:\Program Files\chromedriver-win64\chromedriver.exe" 

# Configuração do WebDriver
service = Service(chrome_driver_path) # Navegador controlado pelo Selenium
options = webdriver.ChromeOptions() # configurar as opções do navegador
options.add_argument("--disable-gpu") # evita possiveis erros gráficos
options.add_argument("--window-size=1920,1080") # define uma resolução fixa

#Inicialização do WebDriver

driver = webdriver.Chrome(service=service, options=options)

url_base = "https://www.kabum.com.br/espaco-gamer/cadeiras-gamer"
driver.get(url_base)
time.sleep(5) # Aguarda 5 segundos para garantir que a página carregue

# Criar um dicionário vazio para armazenar as marcas e preços das cadeiras
dic_produtos = {"marca":[], "preco":[]}

# Vamos iniciar na pagina 1 e incrementamos a cada troca de página
pagina = 1

while True:
    print(f"\n Coletando dados da página {pagina}...")

    try:
        #WebDriverWait(driver, 10): cria uma espera de até 10 seg
        # until(...) faz com que o código espere até que a condição seja verdadeira

        #ec.presence_of_all_elements_located((...)) verifica se todos os elementos "productCard"
        # estão acessíveis
        # By.CLASS_NAME,"productCard": indica que a busca será feita através da classe css
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.CLASS_NAME,"productCard"))
        )
        print("Elementos encontrados com sucesso")
    except TimeoutException:
        print("Tempo de espera excedido!")

    produtos = driver.find_elements(By.CLASS_NAME, "productCard")

    for produto in produtos:
        try:
            nome = produto.find_element(By.CLASS_NAME, "nameCard").text.strip()
            preco = produto.find_element(By.CLASS_NAME, "priceCard").text.strip()

            print(f"{nome} - {preco}")

            dic_produtos ["marca"].append(nome)
            dic_produtos ["preco"].append(preco)
        except Exception:
            print("Erro ao coletar dados:", Exception)
    # encontrar o acesso para a próxima página
    # fechar o navegador
    # dataframe
    # salvar os dados em csv()

