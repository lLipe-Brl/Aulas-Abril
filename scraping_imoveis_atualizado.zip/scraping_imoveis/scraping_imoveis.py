# Fabiana Rodriqgues, Lais Morares, Geovanna Pereira, Vitória Galutti, Filipe Marin

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException
import pandas as pd
import time

chrome_driver_path = "C:/Program Files/chromedriver-win64/chromedriver.exe"
service = Service(chrome_driver_path) 
options = webdriver.ChromeOptions() 
options.add_argument('--disable-gpu')
options.add_argument('--window-size=1920,1080') 


# Navegar pelo site
driver = webdriver.Chrome(service=service, options=options)
url = 'https://www.vivareal.com.br/aluguel/sp/sao-caetano-do-sul/casa_residencial/?transacao=aluguel&onde=,S%C3%A3o%20Paulo,S%C3%A3o%20Caetano%20do%20Sul,,,,,city,BR%3ESao%20Paulo%3ENULL%3ESao%20Caetano%20do%20Sul,-23.616443,-46.567958,&tipos=casa_residencial&pagina=1'
driver.get(url)
driver.maximize_window()
start_time = time.time()
time.sleep(5)

# Criando um Dicionário, separando por nome e valor 
dicionario = {'metragem (m²)': [], 'quartos': [], 'banheiros': [], 'vagas': [], 'aluguel': [], 'iptu': [], 'nome_da_rua': []}
pagina = 1
total_imoveis = 0
limite = 100

# Looping para acessar cada página até o final
while total_imoveis < limite:
    print(f"\nColetando dados da página {pagina}...")


    # Coletar todos os cards
    cards = driver.find_elements(By.CSS_SELECTOR, '[data-cy="rp-property-cd"]')
    print(len(cards))

    for card in cards:
        if total_imoveis >= limite:
            break
        # Para cada card, tentar capturar todas as informações
        try:
            metragem = card.find_element(By.CSS_SELECTOR, '[data-cy="rp-cardProperty-propertyArea-txt"] h3').text.strip()
        except:
            metragem = None

        try:
            quartos = card.find_element(By.CSS_SELECTOR, '[data-cy="rp-cardProperty-bedroomQuantity-txt"] h3').text.strip()
        except:
            quartos = None

        try:
            banheiros = card.find_element(By.CSS_SELECTOR, '[data-cy="rp-cardProperty-bathroomQuantity-txt"] h3').text.strip()
        except:
            banheiros = None

        try:
            vagas = card.find_element(By.CSS_SELECTOR, '[data-cy="rp-cardProperty-parkingSpacesQuantity-txt"] h3').text.strip()
        except:
            vagas = None

        try:
            preco_element = card.find_element(By.CSS_SELECTOR, '[data-cy="rp-cardProperty-price-txt"]')
            preco_texto = preco_element.find_elements(By.TAG_NAME, 'p')
            
            aluguel = preco_texto[0].text.strip() if len(preco_texto) > 0 else None
            iptu = preco_texto[1].text.strip() if len(preco_texto) > 0 else None
        except:
            aluguel = None
            iptu = None

        try:
            rua_element = card.find_elements(By.CSS_SELECTOR, '[data-cy="rp-cardProperty-street-txt"]')
            nome_da_rua = rua_element[0].text.strip() if rua_element else None
        except:
            nome_da_rua = None

        # Adiciona todos ao dicionário
        dicionario['metragem (m²)'].append(metragem)
        dicionario['quartos'].append(quartos)
        dicionario['banheiros'].append(banheiros)
        dicionario['vagas'].append(vagas)
        dicionario['aluguel'].append(aluguel)
        dicionario['iptu'].append(iptu)
        dicionario['nome_da_rua'].append(nome_da_rua)

        total_imoveis += 1  # Atualiza o contador

    if total_imoveis >= limite:
        print("Limite de imóveis alcançado.")
        break

    # Avançar para a próxima página
    try:
        botao_proxima = WebDriverWait(driver, 5).until(
            ec.element_to_be_clickable((By.CSS_SELECTOR, '[data-testid="next-page"]'))
        )
        pagina_atual = driver.current_url
        driver.execute_script("arguments[0].scrollIntoView();", botao_proxima)
        time.sleep(1)
        driver.execute_script("arguments[0].click();", botao_proxima)
        time.sleep(3)
        if driver.current_url == pagina_atual:
            print("A URL não mudou. Provavelmente a última página.")
            break
        pagina += 1

    except Exception as excecao:
        print("Erro ao tentar avançar para a próxima página:", excecao)
        break
# Saindo do programa
driver.quit()

# Salvando os dados num novo arquivo Excel (.xlsx)
df = pd.DataFrame(dicionario)
df.to_excel("imoveis_teste.xlsx", index=False)

print(f"Arquivo imoveis_sc salvo com sucesso! ({len(df)}) produtos capturados")